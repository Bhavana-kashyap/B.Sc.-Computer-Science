#include <iostream>
using namespace std;

void swap(int*start,int*end){
    int temp=*start;
    *start=*end;
    *end=temp;
}
int main(){
    cout<<"Enter the no of elements in array: ";
    int n;
    cin>>n;
    int arr[n];
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int m= sizeof(arr)/sizeof(arr[0]);
    int option;
    cout<<" Press 1 to get even valued element "<<endl;
    cout<<" Press 2 to get odd valued element "<<endl;
    cout<<" Press 3 to get sum and average of elements"<<endl;
    cout<<" Press 4 to get maximum and minimum element of array"<<endl;
    cout<<" Press 5 to remove duplicate"<<endl;
    cout<<" Press 6 to reverse array"<<endl;
    cin>>option;
    switch(option){
    
    // print even valued element
    case 1:
    { cout<<"Even valued element: ";
    for(int i=0;i<=m-1;i++){
        if(i%2==0){
            cout<<arr[i]<<" ";
        }
    
    }
    cout<<endl;
    }
    break;
    case 2:
    {// print odd valued element
    cout<<"Odd value element: ";
    for(int i=0;i<=m-1;i++){
        if(i%2==1){
            cout<<arr[i]<<" ";
        }
    }
    cout<<endl;
    break;
    }
    case 3:
    {//sum and average of the elements
    float sum=0;
    for(int i=0;i<=m-1;i++){
        sum+=arr[i];
    }
    cout<<"sum of element of array: "<<sum<<endl;
    cout<<"Average of elements of array: "<<sum/m<<endl;
    }
    break;

    case 4:
    {
    // print maximum and minimum element of array
    int max=arr[0];
    int min=arr[0];
    for(int i=1;i<m;i++){
        if(arr[i]>max){
            max=arr[i];
        }
    }
    cout<<"Maximum of elements: "<<max<<endl;
    for(int i=1;i<m;i++){
        if(arr[i]<min){
            min=arr[i];
        }
    }
     cout<<"Minimum of elements: "<<min<<endl;
    }
    break;
    case 5:
    {
    //  remove duplicates from the array
    int temp[n];
    int j = 0;
    for (int i=0; i<n-1; i++){
            if (arr[i] != arr[i+1])
            temp[j++] = arr[i];
    }
    // Store the last element as whether
    // it is unique or repeated, it hasn't
    // stored previously
    temp[j++] = arr[n-1];
 
    // Modify original array
    for (int i=0; i<j; i++){
        arr[i] = temp[i];
    }
    cout<< "Array after removing duplicates: ";
    for(int i=0;i<j;i++){
        cout<<temp[i]<<" ";
    }
    }
    break;
    case 6:
    {
    // Reverse array
    int* start=arr;
    int* end=&arr[m-1];
    cout<<endl;
    while(start<end){
        swap(start,end);
        start++;
        end--;
    }
    for (int i=0;i<m;i++){
             cout<<arr[i]<<"   ";
            
        }
    }
    break;
}
    return 0;
}