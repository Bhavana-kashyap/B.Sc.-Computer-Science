#include<iostream>
using namespace std;

class Box{
    public: 
    int length,breadth,height;
    Box(){} // empty constructor
    Box(int _length,int _breadth, int _height){
        length = _length;
        breadth = _breadth;
        height = _height;
    }
    int surfaceArea(){
        return (2*(length+breadth)*height);
    }
    int Volume(){
        return (length*breadth*height);
    }
    Box operator ++(int n){ //postfix ++
        length++;
        breadth++;
        height++;
        return *this;
    }
    Box operator --(int n){ //postfix --
        length--;
        breadth--;
        height--;
        return *this;
    }
    Box operator ++(){ // prefix ++
        ++length;
        ++breadth;
        ++height;
        return *this;
    }
    Box operator --(){ // prefix --
        --length;
        --breadth;
        --height;
        return *this;
    }
    bool operator ==(Box otherbox){
        return (this->length==otherbox.length && this->breadth == otherbox.breadth && this->height==otherbox.height);
    }
    bool isCube(){
        return (length == breadth && breadth == height);
    }
    void operator = (Box otherbox){
        this->length=otherbox.length;
        this->breadth=otherbox.breadth;
        this->height=otherbox.height;
    }
    void operator = (int dimensions[3]){
        this->length=dimensions[0];
        this->breadth=dimensions[1];
        this->height=dimensions[2];
    }

};

int main(){
    // sample code
    Box b1(1,2,3),b2(1,2,4);
    if (b1==b2)
        cout<<"box are equal\n";
    else
        cout<<"box are not equal\n";
    Box b3=b1;
    Box b4 = {1,2,3};
    if (b4==b1)
        cout<<"b4 and b1 are equal\n";
    else
        cout<<"b4 and b1 are not equal\n";
    Box b5 = {3,4,3};
    if (b5.isCube())
        cout << "b5 is a cube";
    else
        cout << "b5 is not a cube";
    return 0;
}