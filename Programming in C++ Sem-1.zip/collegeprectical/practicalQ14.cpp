#include <iostream>
using namespace std;
void Area(int n){
    cout<<3.1414*(n^2);
}
void Circumferance(int n){
    cout<<2*3.141*n;
}

int main(){
    cout<<"Enter the radius of circle: ";
    int n;
    cin>>n;
    cout<<"Area of circle: ";
    Area(n);
    cout<<endl;
    cout<<"Circumferance of circle: ";
    Circumferance(n);
    return 0;
}