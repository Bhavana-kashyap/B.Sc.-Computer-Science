//WAP to print the sum and product of digits of an integer. 
#include <iostream>
using namespace std;

int main(){
    cout<<"Enter your integer : ";
    int n,sum,product;
    sum=0;
    product=1;
    cin>>n;
    while(n>0){
        int lastdig=n%10;
        sum+=lastdig;
        product*=lastdig;
        n/=10;
    }
    cout<<"Sum of digits of the integer: "<<sum;
    cout<<endl;
    cout<<"Product of digits of the integer: "<<product;
}