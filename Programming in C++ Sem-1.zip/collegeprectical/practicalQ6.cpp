#include <iostream>
#include <time.h>
using namespace std;

bool isprime(int n){
    if(n<=1){
        return false;
    }
    else{
        int c=2;
        while(c*c<=n){
          if(n%c==0){
              return false;
          }
          c++;
        }
    
 return true;
    }
}
int main(){
    int p=isprime(21);
    if(p==1){
        cout<<"prime number"<<endl;
    }
    else{
        cout<<"Not a prime"<<endl;
    }
        cout<<"Prime numbers less than 100: ";
        for(int i=0;i<=100;i++){
            if(isprime(i)==1){
                cout<<i<<" ";
            }
        }
    

   
    return 0;
}