#include<iostream>
using namespace std;

void reverse_array(int *arr, int length){
    int temparray[length] = {0};
    for (int i=0;i<length;i++){
        temparray[i] = arr[length-i-1];
    }
    for (int i=0;i<length;i++){
        arr[i] = temparray[i];
    }
}

int main(){
    int arr[] = {1,2,3,4,5,6};
    int length = sizeof(arr)/sizeof(arr[0]);
    reverse_array(arr,length);
    cout<<"final output is : \n";
    for (int i=0;i<length;i++){
        cout<<arr[i]<<endl;
    }
    return 0;
}