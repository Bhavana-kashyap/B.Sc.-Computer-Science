#include<iostream>
using namespace std;
int main(){
    int n1,n2;
    cout<<"enter your limit : ";
    cin >>n1;
    int arr1[n1] = {0};
    cout<<"enter elements of array 1 : ";
    for (int i = 0; i < n1; i++){
        cin >> arr1[i];
    }

    cout<<"enter your limit : ";
    cin >>n2;
    int arr2[n2] = {0};
    cout<<"enter elements of array 2: ";
    for (int i = 0; i < n2; i++){
        cin >> arr2[i];
    }
    int arr3[n1+n2] = {0};
    for (int i = 0; i < n1+n2; i++){
        if (i < n1)
        arr3[i] = arr1[i];
        else
        arr3[i] = arr2[i-n1];
    }
    // sort array (insertion sorting algorithm)
    int key,j;
    for (int i=1;i<n1+n2;i++){
        key = arr3[i];
        j = i-1;
        while (j>=0 && arr3[j] > key){
            arr3[j+1] = arr3[j]; // shift element  
            j--;
        }
        arr3[j+1] = key;
    }

    // display the array
    for (int i=0;i<n1+n2;i++){
        cout<<arr3[i]<<" ";
    }
    return 0;
}