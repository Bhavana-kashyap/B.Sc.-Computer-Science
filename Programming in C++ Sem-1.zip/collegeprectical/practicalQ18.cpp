#include<iostream>
using namespace std;
// Using recursion
int fibrecursion(int n){
    if(n<2){
        return n;
    }
    int c=(fibrecursion(n-1)+fibrecursion(n-2));
    return c;
}
int main(){
    // Using iteration
    int fab1=0;
    int fab2=1;
    cout<<"how many terms you want in series: ";
    int n;
    cin>>n;
    cout<<fab1<<",";
    cout<<fab2<<",";
    for(int x=1;x<n-1;x++){
        int fab3=fab1+fab2;
        cout<<fab3<<",";
        fab1=fab2;
        fab2=fab3;
    }
    int b=fibrecursion(7);
    cout<<b;
}