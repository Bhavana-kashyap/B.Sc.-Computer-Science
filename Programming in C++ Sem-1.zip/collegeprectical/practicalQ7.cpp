#include <iostream>
using namespace std;
void factors(int a){
    int c=1;
    cout<<"Factors of "<<a<<" is: ";
    while(a>=c){
        if(a%c==0){
            cout<< c<<" ";
        }
        c++;
    }
}

int main(){
    factors(36);
}