#include<iostream>
using namespace std;
int factorial(int num,int fact=1){
    if (num <= 0){
        return fact;
    }
    fact*=num;
    num--;
    return factorial(num,fact);
    
}
int main(){
    int num;
    cout << "enter your number : ";
    cin >> num;
    cout << "the factorial of the number is : " << factorial(num);
    return 0;
}