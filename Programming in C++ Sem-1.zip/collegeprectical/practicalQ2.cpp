//WAP to reverse a number. 
#include <iostream>
using namespace std;

int main(){
    cout<<"Enter your integer : ";
    int n,ans;
    ans=0;
    cin>>n;
    while(n>0){
        int lastdig=n%10;
        ans=ans*10+lastdig;
        n/=10;
    }
    cout<<"Reverse of your number: "<<ans;
    return 0;
}