#include<iostream>
using namespace std;

int AlphabetCount(string str, char chr){
    int count = 0;
    for (int i=0;i<str.length();i++){
        if (str[i] == chr){
            count++;
        }
    }
    return count;
}
bool IfCharExists(char characters[],int lenght,char chr){
    for (int i=0;i<lenght;i++){
        if (characters[i] == chr){
            return true;
        }
    }
    return false;
}
int main()
{
    string inputString;
    cout<<"Enter your string: ";
    cin>>inputString;
    char characters[inputString.length()];
    cout<<"Alphabets\tcount"<<endl;
    for (int i=0;i<inputString.length();i++){
        char character = inputString[i];
        int count = AlphabetCount(inputString,character);
        if (!IfCharExists(characters,inputString.length(),character)){
            characters[i] = character;
            cout<<character<<"\t\t"<<count<<endl;
        }
    }
    return 0;
}
