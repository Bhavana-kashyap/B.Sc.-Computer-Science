#include <iostream>
using namespace std;

int main(){
    int n;
    cout<<"enter the numbers of lines you want in pattern: ";
    cin>>n;
    for (int row=1;row<=n;row++){
        for(int spc=n-row;spc>=1;spc--){
            cout<<" ";
        }
        for(int col=1;col<=row+row-1;col++){
            cout<<"*";
        }
        cout<<endl;
    }
    return 0;
}