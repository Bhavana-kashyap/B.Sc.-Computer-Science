#include<iostream>
using namespace std;
int GCD(int num1, int num2, int multiple=1){
    int product = num1*num2;
    if (multiple % num1 == 0 && multiple % num2 == 0 ){
        int gcd = abs(product)/multiple;
        return gcd;
    }
    multiple++;
    GCD(num1,num2,multiple);
}
int main(){
    int num1,num2;
    cout << "enter two number : ";
    cin >> num1 >> num2;
    cout << "GCD of the two numbers is : " << GCD(num1, num2);
    return 0;
}