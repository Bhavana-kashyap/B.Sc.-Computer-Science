#include<iostream>
#include<fstream>
using namespace std;

void writeintofile(string line){
    ofstream ofile;
    string finalline = "";
    ofile.open("practicalQ26(output).txt",ios::app);
    for (char chr : line){
        if (chr != ' '){
            finalline += chr;
        }
    }ofile << finalline << endl;
}

int main(){
    ifstream ifile;
    ifile.open("practicalQ26(input).txt",ios::in);
    while (!ifile.eof()){ //reading from file until end of the file
        string line;
        getline(ifile,line);
        writeintofile(line);
    }
    ifile.close();
    return 0;
}