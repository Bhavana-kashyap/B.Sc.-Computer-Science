#include<iostream>
using namespace std;
int main(){
    cout<<"enter elements of your array : "<<endl;
    int array[10] = {0};
    for (int i=0;i<10;i++){
        cin >> array[i];
    }
    int *ptr = array;
    cout << "ascending order : "<<endl;
    for (int i=0;i<10;i++){
        cout<<*ptr<<" ";
        ptr++;
    }
    ptr--;
    cout<<endl;
    cout << "descending order : "<<endl;
    for (int i=0;i<10;i++){
        cout<<*ptr<<" ";
        ptr--;
    }
    return 0;
}