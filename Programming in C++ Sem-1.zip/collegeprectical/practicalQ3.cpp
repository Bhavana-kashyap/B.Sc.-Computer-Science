//WAP to compute the sum of the first n terms of the following series S = 1+1/2+1/3+1/4+……
#include <iostream>
using namespace std;

int main(){
    double n,sum;
    cout<<"Enter the number of terms : ";
    cin>>n;
    sum=0;
    for(double i=1;i<=n;i++){
        sum+=(1/i);
    }
    cout<<"sum of the series : "<<sum;
    return 0;
}