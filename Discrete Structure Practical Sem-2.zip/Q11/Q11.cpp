#include<iostream>
using namespace std;

int factorial(int n){
	if (n == 1)
		return 1;
	else
		return n * factorial(n-1);
}

float permutation(int n, int r){
	return float(factorial(n))/factorial(n-r);
}
float combination(int n, int r){
	return float(factorial(n))/(factorial(n-r) * factorial(r));
}

int main(){
	cout << combination(5,2);
	return 0;
}