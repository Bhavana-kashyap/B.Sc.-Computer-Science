package college.pack1.P;

import college.pack1.P1.TwoDim;
import college.pack1.P2.ThreeDim;

public class Main {
   public static void main(String[] args) {
       TwoDim obj= new ThreeDim();
       System.out.println(obj.toString());
   }
}
