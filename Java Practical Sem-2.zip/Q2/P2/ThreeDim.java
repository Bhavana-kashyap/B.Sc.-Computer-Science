package college.pack1.P2;

import college.pack1.P1.TwoDim;

public class ThreeDim extends TwoDim {
      private int z;
      public ThreeDim(){
          super();
          this.z=0;
      }
      public ThreeDim(int z){
          this.z=z;
      }
      @Override
      public String toString(){
          System.out.println(super.toString());
          return ("Your z coordinate is "+z);
      }

}
