package college.pack1.Q11;

import java.awt.*;
import java.awt.event.*;
public class TypeChar extends Frame
{
    String str = " ";
    public TypeChar()
    {
        addKeyListener(new MyKeyAdapter(this));
        addWindowListener(new MyWindowAdapter());
        setSize(500,500);
        setVisible(true);
    }
    public static void main(String[] args)
    {
        TypeChar p = new TypeChar();
        p.setTitle("My Frame");
    }
    public void paint(Graphics g)
    {
        g.drawString(str, 50, 50);
    }
}
class MyWindowAdapter extends WindowAdapter
{
    public void windowClosing(WindowEvent we)
    {
        System.exit(0);
    }
}
class MyKeyAdapter extends KeyAdapter
{
    TypeChar t;
    public MyKeyAdapter(TypeChar t)
    {

        this.t = t;
    }
    public void keyTyped(KeyEvent ke)
    {
        char c = ke.getKeyChar();
        t.str = "Typed character is: "+ c;
        t.repaint();
    }
}
