package college.pack1.Q7;



import java.util.Scanner;
import java.io.*;
public class Filecopy {
    public static void main(String[] input)
    {
        String fname;
        Scanner scan = new Scanner(System.in);
        String line = null;
        System.out.print("Enter File Name to Open (with extension like C:\\Users\\Shubhangi\\Desktop\\filename.txt) : ");
        fname = scan.nextLine();
        try
        {

            FileReader fileReader = new FileReader(fname);
            BufferedReader bufferedReader = new
                    BufferedReader(fileReader);
            line = bufferedReader.readLine();
            while(line != null )
            {
                if(line.charAt(0)=='/' && line.charAt(1)=='/'){
                    System.out.println(line);
                }
                line=bufferedReader.readLine();
            }
            bufferedReader.close();
        }
        catch(IOException ex)
        {
            System.out.println("Error reading file named '" + fname + "'");
        }
    }
}
