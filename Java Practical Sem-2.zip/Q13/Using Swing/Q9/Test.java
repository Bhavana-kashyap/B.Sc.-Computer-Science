package college.pack1.Q13.Q9;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
public class Test
{
    public static void main (String [] a) {
        SwingUtilities.invokeLater (new Runnable () {
            @Override
            public void run () {
                showGUI ();
            }

        }
        );
    }
    private static void showGUI () {
        JFrame frame = new JFrame ("Background display");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.setContentPane (new DrawPanel (Color.PINK,
                Color.YELLOW));
        frame.pack ();
        frame.setLocationRelativeTo (null);
        frame.setVisible (true);
    }
}
class DrawPanel extends JPanel
{
    Color fColor;
    public DrawPanel (Color bgColor, Color fColor) {
        setBackground (bgColor);
        this.fColor = fColor;
    }
    @Override
    public Dimension getPreferredSize () {
        return new Dimension (400, 400);
    }
    @Override protected void paintComponent (Graphics g) {
        super.paintComponent (g);
        g.setColor (fColor);
        g.setFont (new Font ("Arial", Font.PLAIN, 24));
        g.drawString ("This is AWT background example.", 20, 20);
    }
}
