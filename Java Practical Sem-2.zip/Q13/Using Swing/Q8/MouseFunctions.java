package college.pack1.Q13.Q8;

import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
public abstract class MouseFunctions extends Frame implements
        MouseListener{
    Label l;
    MouseFunctions(){
        addMouseListener(this);
        l=new Label();
        l.setBounds(20,50,100,20);
        add(l);
        setSize(300,300);
        setLayout(null);
        setVisible(true);
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        setSize(300,300);
        l.setText("Mouse Clicked");
        repaint();
    }
    @Override
    public void mouseEntered(MouseEvent e) {
        setSize(900,900);
        l.setText("Mouse Entered");
        repaint();
    }
    @Override
    public void mouseExited(MouseEvent e) {
        l.setText("Mouse Exited");
        System.exit(0);

    }
    @Override
    public void mousePressed(MouseEvent e) {
    }
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    public static void main(String[] args) {
        MouseFunctions m = new MouseFunctions() {
        };
        m.setTitle("Mouse Functions Display");
        System.out.println("End");
    }
}