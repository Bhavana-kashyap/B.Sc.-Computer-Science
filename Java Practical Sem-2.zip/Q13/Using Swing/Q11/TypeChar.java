package college.pack1.Q13.Q11;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TypeChar{
    private DrawPanel dp;
    JFrame j=new JFrame("EVENT HANDLING");
    String msg="";
    public TypeChar (){
        dp=new DrawPanel();
        j.addKeyListener(new KeyAdapter(){
            public void keyTyped(KeyEvent ke){
                char ch=ke.getKeyChar();
                msg+=ch;
                j.repaint();
            }
        });

        j.add(dp);
        j.setSize(500,500);
        j.setVisible(true);
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private class DrawPanel extends JPanel{
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawString("Typed character is :"+ msg,50,100);
        }
    }
    public static void main(String args[]){
        TypeChar t=new TypeChar();
    }
}

