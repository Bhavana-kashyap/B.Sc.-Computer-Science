package college.pack1.Q13.Q12;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class ButtonsFrame implements ActionListener {
    private DrawPanel dp;
    JFrame j = new JFrame("EVENT HANDLING");
    JButton b1, b2;
    String msg = "";

    public ButtonsFrame() {
        dp = new DrawPanel();
        b1 = new JButton("A");
        b2 = new JButton("B");
        b1.addActionListener(this);
        b2.addActionListener(this);
        j.add(dp);
        dp.add(b1);
        dp.add(b2);
        j.setVisible(true);
        j.setSize(800, 800);
        j.setTitle("Q9 CLASS");
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            String str = b1.getActionCommand();
            if (str.equals("A")) {
                msg = " Name : Shubhangi Bhatia ||";
                msg += " Course : BSc(hons) Computer Science ||";
                msg += " Roll no : 19570050 ||";
                msg += " College: Kalindi College, University of Delhi";
                j.repaint();
            }
        } else if (ae.getSource() == b2) {
            String str1 = b2.getActionCommand();
            if (str1.equals("B")) {
                msg = "CGPA in previous semester : 7.45";
                j.repaint();
            }
        }
    }

    private class DrawPanel extends JPanel {
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawString(msg, 50, 150);

        }
    }

    public static void main(String args[]) {
        ButtonsFrame bf = new ButtonsFrame();
    }
}