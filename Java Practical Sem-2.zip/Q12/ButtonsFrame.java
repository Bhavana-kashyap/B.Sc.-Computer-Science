package college.pack1.Q12;

import java.awt.*;
import java.awt.event.*;
public class ButtonsFrame extends Frame implements ActionListener
{
    String m = "";
    ButtonsFrame()
    {
        addWindowListener(new WindowAdapter(){ public void
        windowClosing(WindowEvent we)
        {System.exit(0);}
        });
        setLayout(new FlowLayout());
        Button A,B;
        A = new Button("A");
        B = new Button();
        B.setLabel("B");
        add(A);
        add(B);
        A.addActionListener(this);
        B.addActionListener(this);
        setSize(2000,1000);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae)
    {
        String str = ae.getActionCommand();
        if(str.equals("A"))
        {

            m = "Name: Shubhangi Bhatia || Course: B.Sc.(Hons) Computer Science || Roll No.: 19570050 || College: Kalindi College, University of Delhi";
        }
        else if(str.equals("B"))
            m = "CGPA in previous semester: 7.45";
        repaint();
    }
    public void paint(Graphics g)
    {
        g.drawString(m, 400, 400);
    }
    public static void main(String[] args)
    {
        ButtonsFrame f = new ButtonsFrame();
        f.setTitle("Buttons Display");
        System.out.println("End");
    }
}
