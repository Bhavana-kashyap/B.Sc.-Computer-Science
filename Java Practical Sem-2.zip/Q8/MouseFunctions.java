package college.pack1.Q8;

import java.awt.*;
import java.awt.event.*;
public class MouseFunctions extends Frame{
    String msg="";
    public MouseFunctions(){
        addMouseListener(new MyMouseAdapter(this));
        addWindowListener(new MyWindowAdapter());
    }
    public void paint(Graphics g){
        g.drawString(msg,20,80);
    }
    public static void main(String[] args){
        MouseFunctions m=new MouseFunctions();
        m.setSize(new Dimension(350,350));
        m.setTitle("My Adapter");
        m.setLayout(new BorderLayout());
        m.setVisible(true);
    }
}
class MyMouseAdapter extends MouseAdapter{

    MouseFunctions ma;
    public MyMouseAdapter(MouseFunctions ma){
        this.ma=ma;
    }
    public void mouseClicked(MouseEvent me) {
        ma.msg="Mouse Clicked.";
        ma.repaint();
    }
    public void mouseEntered(MouseEvent me){
        ma.setVisible(true);
        ma.msg="Mouse Entered.";
        ma.repaint();
    }
    public void mouseExited(MouseEvent me){
        ma.msg="Mouse Exited.";
        ma.setVisible(false);
        ma.repaint();
    }
}
class MyWindowAdapter extends WindowAdapter{
    public void windowClosing(WindowEvent we){
        System.exit(0);
    }
}
