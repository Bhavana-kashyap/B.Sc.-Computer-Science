package college.pack1.Q10;

import java.awt.Frame;
import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.*;
public class ChangeColour extends Frame implements ActionListener{
    Button red, blue;
    public ChangeColour(){
        red = new Button("Red");
        blue = new Button("Blue");
        setLayout(new FlowLayout());
        add(red);
        add(blue);
        red.addActionListener(this);
        blue.addActionListener(this);
    }
    public static void main(String[] args) {
        ChangeColour c = new ChangeColour();
        c.setTitle("Changing background colur of frame");
        c.setSize(300,300);
        c.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String clickButton = e.getActionCommand();
        System.out.println(clickButton + "clicked");
        if(e.getSource() == red){
            setBackground(Color.red);
        }else{
            setBackground(Color.blue);
        }
    }
}
