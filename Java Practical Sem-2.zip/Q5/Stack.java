package college.pack1.Q5;

class stack{
    int array[];
    int tos;
    public stack(){
        tos=-1;
        array=new int[3];
    }
    void push(int val) throws pushpop{
        if(tos>=2)
            throw ( new pushpop("Overflow"));
        else
            array[++tos]=val;
    }
    int pop( ) throws pushpop{
        int x=-1;
        if(tos<=-1)
            throw new pushpop("underflow");
        x=array[tos];
        tos--;
        return (x);
    }
}
