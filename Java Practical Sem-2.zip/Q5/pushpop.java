package college.pack1.Q5;

class pushpop extends Exception {
    private String str;

    public pushpop(String s) {
        str = s;
    }

    public String toString() {
        return "value is : " + str;
    }
}