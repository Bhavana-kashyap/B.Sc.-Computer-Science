package college.pack1.Q5;

public class ArrayStack {
    public static void main(String args[]) {
        stack s = new stack();
        try {
            s.push(7);
            s.push(6);
            s.push(5);
            s.push(3);
        } catch (pushpop pp) {
            System.out.println("caught :" + " " + pp);
        }
        try {
            System.out.println("the popped object is " + s.pop());
            System.out.println("the popped object is " + s.pop());
            System.out.println("the popped object is " + s.pop());
            System.out.println("the popped object is " + s.pop());
        } catch (pushpop pp) {
            System.out.println("caught :" + pp);
        }
    }
}