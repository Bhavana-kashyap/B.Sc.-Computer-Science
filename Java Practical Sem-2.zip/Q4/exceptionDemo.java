package college.pack1.Q4;

import java.util.Scanner;

public class exceptionDemo {


    void test(int age) throws UnderAge {
        if(age<18){
            try {
                throw new UnderAge("Underage");
            } catch (UnderAge e) {
                System.out.println(e.getMessage()+ " :"+ age);
                System.out.println("Age should be above 18");
            }
        }
        else{
            System.out.println("Valid age");
        }
    }

    public static void main(String[] args) throws UnderAge {

        exceptionDemo obj=new exceptionDemo();
        System.out.print("Enter your age :");
        Scanner in=new Scanner(System.in);
        int a=in.nextInt();

        obj.test(a);
    }
}
