package college.pack1.Q4;

public class UnderAge extends Exception{
           UnderAge(String a){
               super(a);
           }
}
