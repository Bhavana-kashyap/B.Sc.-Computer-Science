package college.pack1.P;

public class ComplexNum {
    public int real;
    public int image;
    ComplexNum(int r, int i){
        this.real=r;
        this.image=i;
    }

    public static ComplexNum add(ComplexNum n1, ComplexNum n2){
        ComplexNum z= new ComplexNum(0,0); // real=0, image=0
        z.real=n1.real+n2.real;
        z.image=n1.image+n2.image;
        return (z);
    }

    public static ComplexNum multiply(ComplexNum n1, ComplexNum n2){
        ComplexNum m= new ComplexNum(0,0);
        m.real=(n1.real*n2.real)-(n1.image* n2.image);
        m.image=(n1.real*n2.image)+(n1.image* n2.real);
        return (m);
    }
    @Override
    public String toString(){
        return (this.real+"+"+"i"+this.image);
    }
        public static void main(String[] args) {
            ComplexNum obj1=new ComplexNum(2,3);
            ComplexNum obj2=new ComplexNum(1,2);
            ComplexNum z=add(obj1,obj2);
            System.out.println(z.toString());
            ComplexNum m=multiply(obj1,obj2);
            System.out.println(m.toString());
        }

}
