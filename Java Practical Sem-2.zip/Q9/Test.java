package college.pack1.Q9;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.awt.event.*;
class Test extends Frame{
    String msg="";
    public Test(){
        addKeyListener(new MyKeyAdapter());
        addWindowListener(new m1());
    }
    public void paint(Graphics g){
        g.drawString(msg,20,80);
    }
    class MyKeyAdapter extends KeyAdapter{
        public void keyTyped(KeyEvent k){
            msg="This is AWT background example";
            repaint();
        }
    }
    class m1 extends WindowAdapter{
        public void windowClosing(WindowEvent we){
            System.exit(0);
        }
    }
    public static void main(String args[]){
        Test t=new Test();
        t.setSize(400,400);
        t.setTitle("Background display");
        t.setVisible(true);
        t.setBackground(Color.PINK);
    }
}
