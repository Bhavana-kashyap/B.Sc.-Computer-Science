package college.pack1.Q6;

import java.io.*;

class CopyExample{
    public static void main(String args[]){
        int i;
        FileInputStream fin = null;
        FileOutputStream fout = null;
        if(args.length!=2){
            System.out.println("File name not provided at command line");
            return ;
        }
        try{
            fin = new FileInputStream(args[0]);
            fout = new FileOutputStream(args[1]);
            do{
                i=fin.read();
                if(i!=-1)
                    fout.write(i);
            }
            while(i!=-1);
        }
        catch(FileNotFoundException e){
            System.out.println("error in opening file"+e);
        }
        catch(IOException e){
            System.out.println("Error in reading"+e);
        }
        finally{
            try{
                fin.close();
                fout.close();
            }
            catch(IOException e){
                System.out.println("File could not be loaded"+e);
            }
        }
    }
}
