package college.pack1.P2;
import college.pack1.P1.Shape;

import java.util.Scanner;

public class Rectangle extends Shape {
   public void Area(){
       Scanner in=new Scanner(System.in);
       System.out.print("Enter the length of Rectangle :");
       int l=in.nextInt();
       System.out.print("Enter the width of Rectangle :");
       int b=in.nextInt();
       System.out.println("Area of Rectangle is : " + l*b);
    }
}
