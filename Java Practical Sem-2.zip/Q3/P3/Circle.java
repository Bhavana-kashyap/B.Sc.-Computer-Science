package college.pack1.P3;
import college.pack1.P1.Shape;

import java.util.Scanner;

public class Circle extends Shape{
    public void Area(){
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the radius of circle");
        int r=in.nextInt();
        System.out.println("Area of Circle is :" +(Math.PI)*r);
    }
}
