package college.pack1.P;

import college.pack1.P1.Shape;
import college.pack1.P2.Rectangle;
import college.pack1.P3.Circle;

import java.util.Scanner;

public class MainArea {
   public static void main(String[] args) {
       System.out.println("Press 1 :To have the Area of Rectangle");
       System.out.println("Press 2 :To have the Area of Circle");

       Scanner in = new Scanner(System.in);
       int a = in.nextInt();
       if(a==1){
           Shape obj =new Rectangle();
           obj.Area();
       } else if (a==2) {

           Shape obj2= new Circle();
           obj2.Area();
       }
       else{
           System.out.println("Invalid input");
       }
   }
}
