package college.pack1.P1;
public abstract class Shape {
    public abstract void Area();
}
